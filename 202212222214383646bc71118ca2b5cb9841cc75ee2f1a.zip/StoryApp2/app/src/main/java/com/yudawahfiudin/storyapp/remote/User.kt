package com.yudawahfiudin.storyapp.remote

data class User(
    val name : String,
    val token : String,
    val isLogin :Boolean
)